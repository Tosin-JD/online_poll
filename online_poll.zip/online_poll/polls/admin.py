from django.contrib import admin
from polls.models import Question, Choice, Topic


# Register your models here.
class ChoiceInLine(admin.TabularInline):
    """add extra spaces for admin to enter
    four choices at once"""
    model = Choice
    extra = 3


class QuestionAdmin(admin.ModelAdmin):
    """register the questions to the admin"""
    """fieldsets = [(None, {'fields': ['topic']}),
        (None, {'fields': ['question_text']}), ('Date Information', {
        'fields': ['pub_date'], 'classes': ['collapse']}), ]"""
    model = Question
    inlines = [ChoiceInLine]



admin.site.register(Question, QuestionAdmin)
admin.site.register(Topic)
