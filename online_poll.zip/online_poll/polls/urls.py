from django.urls import path
from polls.views import (QuestionList,
                         QuestionDetail, ResultList,
                         ResultPage, AllResults,
                         vote)
from comments.views import CreateComment, EditComment

app_name = 'polls'

urlpatterns = [
    path('', QuestionList.as_view(), name='home'),
    path('<int:pk>/detail/', QuestionDetail.as_view(), name='detail'),
    path('<int:question_id>/vote/', vote, name='vote'),
    path('result/', ResultList.as_view(), name='all_result'),
    path('<int:pk>/result/', ResultPage.as_view(), name='results'),
    path('result/', AllResults.as_view(), name='all_results'),
    path('<int:question_id>/comment/',  CreateComment.as_view(), name='create_comment'),
    path('<int:pk>/edit-comment/', EditComment.as_view(), name='edit_comment'),
    path('<int:pk>/delete-comment/', EditComment.as_view(), name='comment_delete'),
]

