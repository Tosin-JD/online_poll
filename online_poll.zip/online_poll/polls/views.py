from django.shortcuts import render, reverse, redirect
from django.urls import reverse_lazy
from django.contrib import messages
from django.views.generic import DetailView, ListView
from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from polls.models import Vote

from polls.models import Question, Choice


# Create your views here.
class QuestionList(ListView):
    """a list of all the questions"""
    model = Question
    template_name = 'polls/question_list.html'


class QuestionDetail(DetailView):
    """showing each question details"""
    model = Question
    template_name = 'polls/question_detail.html'
    
    
class ResultList(ListView):
    """show the list of results for each page"""
    model = Question
    template_name = 'polls/all_result.html'


class ResultPage(DetailView):
    """show the result for each vote that user made"""
    model = Question
    template_name = 'polls/result.html'
    
    
class AllResults(ListView):
    model = Question
    template_name = 'polls/allresults.html'


@login_required
def vote(request, question_id):
    """allow users to vote on any question
    return the page of the question list"""
    question = get_object_or_404(Question, pk = question_id)
    try:
        selected_choice = question.choice_set.get(pk = request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        # Redisplay the question voting form.
        return render(request, 'polls/detail.html', {
            'question': question,
            'error_message': "You didn't select a choice.",
        })
    else:
        if Vote.objects.filter(choice=selected_choice, voter=request.user).exists():
            messages.error(request, "Already voted on this choice")
            return redirect(reverse_lazy('polls:results', args=(question.id, )))
        else:
            selected_choice.votes += 1
            selected_choice.save()
            Vote.objects.create(choice=selected_choice, voter=request.user)
            return redirect("polls:results", pk="question.pk")
        # Always return an HttpResponseRedirect after successfully dealing
        # with POST data. This prevents data from being posted twice if a
        # user hits the Back button.
        return HttpResponseRedirect(reverse('polls:results', args=(question.id, )))
