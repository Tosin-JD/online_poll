from django.db import models
from accounts.models import MyUser


# Create your models here.
class Topic(models.Model):
    """the topics that each questions should
    belong to"""
    topic_text = models.CharField(max_length=50)
    
    def __str__(self):
        return self.topic_text


class Question(models.Model):
    """table for each question that is to be voted on """
    topic = models.ForeignKey(Topic, on_delete=models.CASCADE)
    question_text = models.CharField(max_length=300)
    question_description = models.TextField()
    pub_date = models.DateTimeField('date published')
    question_image = models.ImageField(upload_to='question/', blank=True)
    
    def get_votes(self):
        """return the total amount of votes
        made on any question"""
        total_votes = 0
        for vt in self.choice_set.all():
            total_votes += vt.votes
        return total_votes

    def __str__(self):
        return self.question_text
    
    
class Choice(models.Model):
    """table for each choice that a user is to make"""
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=256)
    votes = models.IntegerField(default=0)
    voted = models.BooleanField(default=False)

    def __str__(self):
        return self.choice_text
    
class Vote(models.Model):
    choice = models.ForeignKey(Choice, on_delete=models.CASCADE)
    voter = models.ForeignKey(MyUser, on_delete=models.CASCADE)