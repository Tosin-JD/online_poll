from django.shortcuts import render, get_object_or_404
from polls.models import Question
from comments import models
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import CreateView, DeleteView, UpdateView
from comments.forms import CommentForm


# Create your views here.
class CreateComment(CreateView, LoginRequiredMixin):
    """this view is for creating comments
    on a post"""
    model = models.Comment
    fields = ('comment_text',)

    def get(self, request, *args, **kwargs):
        """override the parent get to get the mother question"""
        self.question = Question.objects.get(id=self.kwargs['question_id'])
        return super(CreateComment, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        """override the parent to add quesiton"""
        self.question = get_object_or_404(Question, id=kwargs['question_id'])
        kwargs['question'] = self.question
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        """override the parent to add the related question"""
        self.question = get_object_or_404(Question, id=self.kwargs['question_id'])
        form.instance.question = self.question
        form.instance.student = self.request.user
        return super().form_valid(form)


class EditComment(LoginRequiredMixin, UpdateView):
    """if a user is to edit their comment"""
    model = models.Comment
    form_class = CommentForm
    template_name = "comments/edit_comment.html"


class DeleteComment(LoginRequiredMixin, DeleteView):
    """This is for deleting comments"""
    model = models.Comment
    template_name = "comments/comment_delete.html"
