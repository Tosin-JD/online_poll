from django.forms import ModelForm
from django import forms
from .models import Comment


class CommentForm(ModelForm):
    """handle all the form for comment"""
    class Meta:
        """specify the fields to be displayed
        and attach the Comment Model to the form"""
        model = Comment()
        fields = ('comment_text',)