from django.db import models
from accounts.models import MyUser
from polls.models import Question
from django.urls import reverse_lazy


# Create your models here.
class Comment(models.Model):
    """model for each comment that is
    related to a user"""
    question = models.ForeignKey(Question,
                                 on_delete=models.CASCADE)
    comment_text = models.CharField(max_length=140)
    student = models.ForeignKey(MyUser, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    
    def get_absolute_url(self):
        return reverse_lazy("polls:detail",
                            kwargs={'pk': self.question.pk})
